﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace ConvertApi.Controllers
{
    public class WrittenTextController : ApiController
    {
        #region private const and enum type
        private const string dollarUnitText = " DOLLARS";
        private const string centUnitText = " CENTS";

        private const string AndText = " AND ";
        private const string AndZeroText = " AND ZERO CENTS";
        private const double MaxValue = 999999.99;

        // Holds the the name of written text for 1 digital value
        private enum DigitalEnum
        {
            Zero,
            One,
            Two,
            Three,
            Four,
            Five,
            Six,
            Seven,
            Eight,
            Nine
        }

        // Holds the name of written text for 2 digitals values
        private enum TensEnum
        {
            Ten = 10,
            Eleven = 11,
            Twelve = 12,
            Thirteen = 13,
            Fourteen = 14,
            Fifteen = 15,
            Sixteen = 16,
            Seventeen = 17,
            Eighteen = 18,
            Nineteen = 19,
            Twenty = 20,
            Thirty = 30,
            Fourty = 40,
            Fifty = 50,
            Sixty = 60,
            Seventy = 70,
            Eighty = 80,
            Ninety = 90
        }

        #endregion

        [Route("Api/WrittenText/ConvertFromNumericalValue")]
        [HttpGet]
        public IHttpActionResult ConvertFromNumericalValue(double input)
        {
            // Verify if input decimal is with the valid value range
            if (input < 0 || input > MaxValue)
            {
                return BadRequest("Input is not within the expected value range 0..999999.99");
            }

            // convert to string for split into Dollars part and the cents part:
            var valueStr = input.ToString();
            var strArray = valueStr.Split(new char[] { '.', ',' });

            // Verify if input has more then 2 decimals
            if (strArray.Length == 2 && strArray[1].Length > 2)
            {
                return BadRequest("Input should be a numerical value with 2 decimals");
            }

            // Convert dollar text: 
            var writtenText = ConvertDollarsText(strArray[0]);

            // case where no decimals, then convert is completed with zero cents
            if (strArray.Length == 1)
            {
                writtenText = writtenText + AndZeroText;
                return Ok(writtenText.ToUpper());
            }

            // Now Convert and append the cents text
            writtenText += AndText;
            var centsText = ConvertCentsText(strArray[1]);
            writtenText += centsText;
            return Ok(writtenText.ToUpper());
        }

        #region private help menthods
        private string ConvertCentsText(string input)
        {
            var cents = int.Parse(input);
            if (input.Length == 1)
            {
                return ConvertTensAmountToText(cents * 10) + centUnitText;
            }

            if (cents / 10 == 0)
            {
                return ConvertDigitalAmountToText(cents % 10) + centUnitText;
            }
            else
            {
                return ConvertTensAmountToText(cents) + centUnitText;
            }
        }

        private string ConvertDollarsText(string input)
        {
            switch (input.Length)
            {
                case 1:
                    return ConvertDigitalAmountToText(int.Parse(input)) + dollarUnitText;

                case 2:
                    return ConvertTensAmountToText(int.Parse(input)) + dollarUnitText;

                case 3:
                    return ConvertHundredAmountToText(int.Parse(input)) + dollarUnitText;

                default:
                    return ConvertThousandAmountToText(int.Parse(input)) + dollarUnitText;
            }
        }

        private string ConvertDigitalAmountToText(int digital)
        {
            return ((DigitalEnum)digital).ToString().ToUpper();
        }

        private string ConvertTensAmountToText(int cents)
        {
            var value = cents > 99 ? cents / 10 : cents;

            var res = new StringBuilder();

            if (value >= 10 && value < 20)
            {
                res.Append(((TensEnum)value).ToString());
                return res.ToString().ToUpper();
            }

            var tens = 10 * (value / 10);
            if (tens != 0)
            {
                res.Append(((TensEnum)tens).ToString());
            }

            var remains = value % 10;
            if (remains != 0)
            {
                if (res.Length > 0)
                {
                    res.Append(" ");
                }

                res.Append(((DigitalEnum)remains).ToString());
            }

            return res.ToString().ToUpper();
        }

        private string ConvertHundredAmountToText(int value)
        {
            var res = new StringBuilder();
            var hundreds = value / 100;
            if (hundreds != 0)
            {
                res.Append(ConvertDigitalAmountToText(hundreds));
                res.Append(" ");
                res.Append("Hundred");
            }

            var tens = value % 100;
            if (tens != 0)
            {
                if (res.Length > 0)
                {
                    res.Append(" ");
                }

                res.Append(ConvertTensAmountToText(tens));
            }

            return res.ToString().ToUpper();
        }

        private string ConvertThousandAmountToText(int value)
        {
            var res = new StringBuilder();
            var thousands = value / 1000;
            if (thousands != 0)
            {
                res.Append(ConvertHundredAmountToText(thousands));
                res.Append(" ");
                res.Append("Thousand");
            }

            var hundreds = value % 1000;
            if (hundreds != 0)
            {
                if (res.Length > 0)
                {
                    res.Append(" ");
                }

                res.Append(ConvertHundredAmountToText(hundreds));
            }

            return res.ToString().ToUpper();
        }
        #endregion
    }
}
