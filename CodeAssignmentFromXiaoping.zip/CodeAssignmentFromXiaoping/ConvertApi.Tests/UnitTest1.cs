﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;
using System.Web.Http.Results;
using ConvertApi.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConvertApi.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void WrittenTextTestsBadRequest()
        {
            var convert = new WrittenTextController();
            Assert.AreEqual("Input is not within the expected value range 0..999999.99", (convert.ConvertFromNumericalValue(-35) as BadRequestErrorMessageResult).Message);
            Assert.AreEqual("Input is not within the expected value range 0..999999.99", (convert.ConvertFromNumericalValue(-0.1) as BadRequestErrorMessageResult).Message);
            Assert.AreEqual("Input is not within the expected value range 0..999999.99", (convert.ConvertFromNumericalValue(999999.991) as BadRequestErrorMessageResult).Message);
            Assert.AreEqual("Input should be a numerical value with 2 decimals", (convert.ConvertFromNumericalValue(5.054) as BadRequestErrorMessageResult).Message);
        }

        [TestMethod]
        public void WrittenDollarsTextTestsSucced()
        {
            var convert = new WrittenTextController();
            Assert.AreEqual("ZERO DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(0) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIVE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(5) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIVE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(05) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIFTEEN DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(15) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIFTEEN DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(015) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("THIRTY FIVE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(35) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ONE HUNDRED TWENTY THREE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(123) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(2123) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FOURTY TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(42123) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("SEVEN HUNDRED FOURTY TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(742123) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("NINE HUNDRED NINETY NINE THOUSAND NINE HUNDRED NINETY NINE DOLLARS AND ZERO CENTS", (convert.ConvertFromNumericalValue(999999) as OkNegotiatedContentResult<string>).Content);
        }

        [TestMethod]
        public void WrittenZeroDollarsTextTestsSucced()
        {
            var convert = new WrittenTextController();
            Assert.AreEqual("ZERO DOLLARS AND FIFTY CENTS", (convert.ConvertFromNumericalValue(0.50) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ZERO DOLLARS AND FIFTY CENTS", (convert.ConvertFromNumericalValue(0.5) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ZERO DOLLARS AND FIFTEEN CENTS", (convert.ConvertFromNumericalValue(0.15) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ZERO DOLLARS AND THIRTY FIVE CENTS", (convert.ConvertFromNumericalValue(0.35) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ZERO DOLLARS AND NINETY NINE CENTS", (convert.ConvertFromNumericalValue(0.99) as OkNegotiatedContentResult<string>).Content);
        }

        [TestMethod]
        public void WrittenTextTestsSucced()
        {
            var convert = new WrittenTextController();
            Assert.AreEqual("FIVE DOLLARS AND FIVE CENTS", (convert.ConvertFromNumericalValue(5.05) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIVE DOLLARS AND FIFTY CENTS", (convert.ConvertFromNumericalValue(5.500) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIVE DOLLARS AND FIFTY CENTS", (convert.ConvertFromNumericalValue(5.5) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIVE DOLLARS AND FIVE CENTS", (convert.ConvertFromNumericalValue(05.05) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("FIFTEEN DOLLARS AND FIFTEEN CENTS", (convert.ConvertFromNumericalValue(15.15) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("ONE HUNDRED TWENTY THREE DOLLARS AND TWENTY FOUR CENTS", (convert.ConvertFromNumericalValue(123.24) as OkNegotiatedContentResult<string>).Content);     
            Assert.AreEqual("TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND NINE CENTS", (convert.ConvertFromNumericalValue(2123.09) as OkNegotiatedContentResult<string>).Content);   
            Assert.AreEqual("FOURTY TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND THIRTY FIVE CENTS", (convert.ConvertFromNumericalValue(42123.35) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("SEVEN HUNDRED FOURTY TWO THOUSAND ONE HUNDRED TWENTY THREE DOLLARS AND NINETY NINE CENTS", (convert.ConvertFromNumericalValue(742123.99) as OkNegotiatedContentResult<string>).Content);
            Assert.AreEqual("NINE HUNDRED NINETY NINE THOUSAND NINE HUNDRED NINETY NINE DOLLARS AND NINETY NINE CENTS", (convert.ConvertFromNumericalValue(999999.99) as OkNegotiatedContentResult<string>).Content);
        }

    }
}
